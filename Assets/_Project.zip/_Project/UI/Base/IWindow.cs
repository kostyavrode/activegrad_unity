public interface IWindow
{
    void Show();

    void Hide();

    bool IsVisible
    {
        get;
    }
}
